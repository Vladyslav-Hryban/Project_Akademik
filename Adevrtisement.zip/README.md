 <h1># Zespołowy projekt aplikacji do kierowania życiem akademickim #</h1>
  <h3>Członkowie zespołu:</h3>
  <h5>
  <br>Marharyta Martsulevich - Lider zespołu
  <br>Vladyslav Hryban - Członek zespołu (programista)
  <br>Yelyzaveta Kovalchuk - Członek zespołu (analityk)
  </h5>
  
  
